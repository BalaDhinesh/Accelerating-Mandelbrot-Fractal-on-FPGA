// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xdut.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XDut_CfgInitialize(XDut *InstancePtr, XDut_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XDut_Start(XDut *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_AP_CTRL) & 0x80;
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XDut_IsDone(XDut *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XDut_IsIdle(XDut *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XDut_IsReady(XDut *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XDut_EnableAutoRestart(XDut *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XDut_DisableAutoRestart(XDut *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_AP_CTRL, 0);
}

void XDut_Set_config_r(XDut *InstancePtr, XDut_Config_r Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 0, Data.word_0);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 4, Data.word_1);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 8, Data.word_2);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 12, Data.word_3);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 16, Data.word_4);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 20, Data.word_5);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 24, Data.word_6);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 28, Data.word_7);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 32, Data.word_8);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 36, Data.word_9);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 40, Data.word_10);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 44, Data.word_11);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 48, Data.word_12);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 52, Data.word_13);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 56, Data.word_14);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 60, Data.word_15);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 64, Data.word_16);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 68, Data.word_17);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 72, Data.word_18);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 76, Data.word_19);
}

XDut_Config_r XDut_Get_config_r(XDut *InstancePtr) {
    XDut_Config_r Data;

    Data.word_0 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 0);
    Data.word_1 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 4);
    Data.word_2 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 8);
    Data.word_3 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 12);
    Data.word_4 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 16);
    Data.word_5 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 20);
    Data.word_6 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 24);
    Data.word_7 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 28);
    Data.word_8 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 32);
    Data.word_9 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 36);
    Data.word_10 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 40);
    Data.word_11 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 44);
    Data.word_12 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 48);
    Data.word_13 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 52);
    Data.word_14 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 56);
    Data.word_15 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 60);
    Data.word_16 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 64);
    Data.word_17 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 68);
    Data.word_18 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 72);
    Data.word_19 = XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_CONFIG_R_DATA + 76);
    return Data;
}

void XDut_InterruptGlobalEnable(XDut *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_GIE, 1);
}

void XDut_InterruptGlobalDisable(XDut *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_GIE, 0);
}

void XDut_InterruptEnable(XDut *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_IER);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_IER, Register | Mask);
}

void XDut_InterruptDisable(XDut *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_IER);
    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_IER, Register & (~Mask));
}

void XDut_InterruptClear(XDut *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDut_WriteReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_ISR, Mask);
}

u32 XDut_InterruptGetEnabled(XDut *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_IER);
}

u32 XDut_InterruptGetStatus(XDut *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDut_ReadReg(InstancePtr->Control_BaseAddress, XDUT_CONTROL_ADDR_ISR);
}

